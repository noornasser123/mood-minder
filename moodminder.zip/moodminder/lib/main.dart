import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';  // Add this import if not done already
import 'screens/home_screen.dart';  // Add this import for HomeScreen

void main() {
  runApp(MoodMinderApp());
}

class MoodMinderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MoodMinder',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/home': (context) => HomeScreen(),
        '/register': (context) => RegisterScreen(),  // Add route for RegisterScreen
      },
    );
  }
}
