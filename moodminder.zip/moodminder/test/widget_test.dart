import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:moodminder/main.dart'; // Correct path to your app

void main() {
  testWidgets('MoodMinderApp widget test', (WidgetTester tester) async {
    // Build the app and trigger a frame.
    await tester.pumpWidget(MoodMinderApp()); // Use MoodMinderApp instead of MyApp

    // Verify that the app's home screen text is displayed
    expect(find.text('Welcome to MoodMinder!'), findsOneWidget);
  });
}
