package com.example.moodminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
